import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { config, environment } from 'src/environments/environment';
import { logdates } from '../failure-stats/failure-stats.component';
import { RestserviceService } from '../restservice.service';
import { CellCustomMilestoneComponent } from '../cell-custom-milestone/cell-custom-milestone.component';
import { AppRoutingModule } from '../app-routing.module';
import { cellCustomComponent } from '../cell-custom/cell-custom.component';
import * as CryptoJS from 'crypto-js';
declare var $: any;


@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  // @Output()
  // buttonClicked: EventEmitter<string> = new EventEmitter<string>();
  recharge: boolean = false;
  billplanchange: boolean = false;
  dealerorder: boolean = false;
  tpdigitalservice: boolean = false;
  digitalplanconfiguration: boolean = false;
  entplanconfiguration: boolean = false;

  public whichdashboard: any;
  public activityname: any;
  public errorcode: any;
  public fromtimestamp: any;
  public totimestamp: any;
  public numberofrows: any;
  public businteraction: any;

  dashboard: any;
  params: any;
  jsonRequest: JSON;
  obj: any;
  public defaultColDef;
  public gridApi;
  columnDefs = [];
  message: any;
  users: any;
  public dateRanage: any;
  startDate: any;
  endDate: any;
  loading: boolean = false;

  time1 = { hour: 0, minute: 0 };
  time2 = { hour: 23, minute: 59 };
  paginationPageSize:any;
  obj1: any;
  jsonRepushRequest: any;
  selectedObj = [];
  finalObj: any;
  username: string = localStorage.getItem('username');

  filter: any = HomeComponent;

  columnobj: any;
  columnJson: JSON;
  errorTracking = [];

  constructor(private router: Router, private service: RestserviceService) {
    this.paginationPageSize = 16;
    this.defaultColDef = {
      flex: 1,
      minWidth: 100,
      enableValue: true,
      enableRowGroup: true,
      enablePivot: true,
      sortable: true,
      filter: true,
    }
  }
  ngOnInit(): void {
    this.hideandshow2()
  }
  clickButton(e) {
    e.show()
  }

  //datepicker configuration
  public today: Date = new Date();
  public currentYear: number = this.today.getFullYear();
  public currentMonth: number = this.today.getMonth();
  public currentDay: number = this.today.getDate();
  public presets = [
    { label: 'Today', start: new Date(), end: new Date() },
    { label: 'This Month', start: new Date(new Date().setDate(1)), end: new Date() }
  ];
  public htmlAttributes = { name: "range", placeholder: "select date" };
  public maxDate: Object = new Date(this.currentYear, this.currentMonth, this.currentDay);
  //datepicker configuration end

  nameChanged1(arg) {
    $("." + "recharge").hide();
    $("." + "billplanchange").hide();
    $("." + "dealerorder").hide();
    $("." + "tpdigitalservice").hide();
    $("." + "digitalplanconfiguration").hide();
    $("." + "entplanconfiguration").hide();
    console.log(arg)
    $(".type").hide();
    $("." + arg).show();
  }

  storedRole:any
  hideandshow2() {
    console.log("function eekldjslj")

    try {
      const bytes = CryptoJS.AES.decrypt(localStorage.getItem("rolep"), environment.encryptSecretKey);
      if (bytes.toString()) {
        console.log("role p is ")
        console.log(JSON.parse(bytes.toString(CryptoJS.enc.Utf8)))
        this.storedRole = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
      }      
    } catch (e) {
      console.log(e);
    }

    //let storedRole = localStorage.getItem("role")
    // this.service.getalldashboardsbyuser().subscribe(data=>{
    //   this.dashboard = data;
    // })
    if (this.storedRole === "admin") {
      this.dashboard = config.admin;
    } else if (this.storedRole === "user") {
      this.dashboard = config.user;
    }

    if (this.dashboard.includes("recharge")) {
      this.recharge = true;
    }
    if (this.dashboard.includes("billplanchange")) {
      this.billplanchange = true
    }
    if (this.dashboard.includes("dealerorder")) {
      this.dealerorder = true;
    }
    if (this.dashboard.includes("tpdigitalservice")) {
      this.tpdigitalservice = true
    }
    if (this.dashboard.includes("digitalplanconfiguration")) {
      this.digitalplanconfiguration = true;
    }
    if (this.dashboard.includes("entplanconfiguration")) {
      this.entplanconfiguration = true
    }

  }

  onRowClicked(args) {
    cellCustomComponent.transrefno = args.data.transrefno
    logdates.logdashboardname = this.whichdashboard
    cellCustomComponent.referenceno = args.data.referenceno
    cellCustomComponent.transDate = args.data.transactiontimestamp
  }

  // requestBuilder() {
  //   let rowData = this.params;
  //   let i = rowData.data;
  //   let errorcode = i.errorcode
  //   var newarr = errorcode.split("-");
  //   var errorResult = newarr[0]
  //   this.obj = {
  //     "dashboard": logdates.logdashboardname,
  //     "fromtimestamp": logdates.logstartDate,
  //     "totimestamp": logdates.logendDate,
  //     "activityname": i.activityname,
  //   }
  //   this.jsonRequest = <JSON>this.obj;
  //   if (errorResult !== undefined && errorResult !== "") {
  //     this.jsonRequest["errorcode"] = errorResult;
  //   }
  //   console.log(this.jsonRequest);
  // }

  requestBuilder1() {
    this.loading = true;
    this.filter = ""
    let currentDate = new Date();
    let earlierDate = new Date();
    if (this.dateRanage !== undefined && this.dateRanage !== null) {
      // this.startDate = this.startDate+ " "+ this.time1.hour+":"+this.time1.minute+":"+"00.000"
      // this.endDate = this.endDate+ " "+ this.time2.hour+":"+this.time2.minute+":"+"00.000"
      let date: Date = new Date(this.dateRanage[0]);
      var month = date.getMonth() + 1
      this.startDate = date.getFullYear() + '-' + ("0" + month).slice(-2) + '-' + ("0" + date.getDate()).slice(-2) + " " + this.time1.hour + ":" + this.time1.minute + ":" + "00.000"
      //let dateStart = date.getFullYear() + '-' + month + '-' + date.getDate()

      let date1: Date = new Date(this.dateRanage[1]);
      var month = date1.getMonth() + 1
      this.endDate = date1.getFullYear() + '-' + ("0" + month).slice(-2) + '-' + ("0" + date1.getDate()).slice(-2) + " " + this.time2.hour + ":" + this.time2.minute + ":" + "00.000"
      //let dateEnd = date1.getFullYear() + '-' + month + '-' + date1.getDate()

      //for date placeholder      
      //this.dateRanage = dateStart + " to " + dateEnd
    } else {
      var month = currentDate.getMonth() + 1
      var earliermonth = earlierDate.getMonth() + 1
      this.startDate = earlierDate.getFullYear() + '-' + ("0" + earliermonth).slice(-2) + '-' + ("0" + earlierDate.getDate()).slice(-2) + " 00:00:00.000"
      this.endDate = currentDate.getFullYear() + '-' + ("0" + month).slice(-2) + '-' + ("0" + currentDate.getDate()).slice(-2) + " 23:59:00.000"
      //this.startDate = "2021-07-26 00:00:00.000"
      //this.endDate = "2021-08-01 23:59:59.999"

    }
    this.obj = {     
      "fromtimestamp": this.startDate,
      "totimestamp": this.endDate
    }
    this.jsonRequest = <JSON>this.obj;
    if(this.whichdashboard !== undefined && this.whichdashboard !== null && this.whichdashboard !== ""){
      this.jsonRequest["dashboard"] = this.whichdashboard;
    }else{
      this.loading = false;
      alert("Please select dashboard");
    }
    if(this.activityname !== undefined && this.activityname !== null && this.activityname !== ""){
      this.jsonRequest["activityname"] = this.activityname;
    }else{
      this.loading = false;
      alert("Please enter activityname");
    }
    if(this.errorcode !== undefined && this.errorcode !== null && this.errorcode !== ""){
      this.jsonRequest["errorcode"] = this.errorcode;
    }else{
      this.loading = false;
      alert("Please enter a valid error code");
    }
    if(this.numberofrows !== undefined && this.numberofrows !== null && this.numberofrows !== ""){
      this.jsonRequest["numberofrows"] = this.numberofrows;
    }
    if(this.businteraction !== undefined && this.businteraction !== null && this.businteraction !== "" && this.whichdashboard === "billplanchange"){
      this.jsonRequest["type"] = this.businteraction;
    }    
    console.log(this.jsonRequest)
  }



  tempFunc() {
    this.obj = { "dashboard": "recharge", "fromtimestamp": "2021-07-07 00:00:00.000", "totimestamp": "2021-08-05 23:59:59.999", "activityname": "ActivateDigitalService", "errorcode": "8108" }
    this.jsonRequest = <JSON>this.obj;
  }

  onGridReady(params) {
    this.tempFunc();
    this.gridApi = params.api;
    //this.gridColumnApi = params.columnApi;
    let dataresp = this.service.errorTracking(this.jsonRequest);
    dataresp.subscribe(data => {
      this.message = data
      var abc = data[0];
      if (abc !== undefined && abc !== "") {
        for (var key in abc) {
          this.columnDefs.push({
            headerName: key, field: key, filter: true,
            sortable: true, sortingOrder: ["asc", "desc"], suppressSizeToFit: true, resizable: true
          })
          //params.api.setColumnDefs(this.columnDefs);
        }
        this.columnDefs.push({
          headerName: 'Actions', field: 'action', cellRendererFramework: CellCustomMilestoneComponent, width: 90,
        })
        params.api.setColumnDefs(this.columnDefs);
        params.api.setRowData([]); //this.users = data
      } else {
        for (var key in this.message.resultStatus) {
          this.columnDefs.push({
            headerName: key, field: key
          })
        }
        console.log(this.message)
        params.api.setColumnDefs(this.columnDefs);
        const usersJson: any[] = Array.of(this.message.resultStatus);
        params.api.setRowData([]);

      }
    })
    this.columnDefs = []
  }

  onGridReady1(params) {
    this.gridApi = params.api;
    // let abc = { "processtimestamp": "", "referenceno": "", "processtype": "", "activityname": "", "transactiontimestamp": "", "errorcode": "", "transrefno": "" }
    // for (var key in abc) {
    //   this.columnDefs.push({
    //     headerName: key, field: key, filter: true,
    //     sortable: true, sortingOrder: ["asc", "desc"], suppressSizeToFit: true, resizable: true
    //   })
    // }
    // this.columnDefs.push({
    //   headerName: 'Actions', field: 'action', cellRendererFramework: CellCustomMilestoneComponent, width: 90,
    // })
    // params.api.setColumnDefs(this.columnDefs);
    this.errorTrackingColumns();
    params.api.setRowData([]);
  }

  role:any;
  dashboardDefault(){
    try {
      const bytes = CryptoJS.AES.decrypt(localStorage.getItem("rolep"), environment.encryptSecretKey);
      if (bytes.toString()) {
        this.role =  JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
      }      
    } catch (e) {
      console.log(e);
    }

    if(this.whichdashboard === undefined || this.whichdashboard === "" || this.whichdashboard === null){
      //var role = localStorage.getItem('role');
      if(this.role === "admin"){
        let roles = config.admin
        this.whichdashboard = roles[0]
      }else if(this.role === "user"){
        let roles = config.user
        this.whichdashboard = roles[0]
      }else{
        alert("undefined role")
      }
    }
  }

  errorTrackingColumns() {
    this.dashboardDefault()
    this.columnobj = {
      "dashboard": this.whichdashboard,
      "parent": "errorTrackingResponse"
    }
    this.columnJson = <JSON>this.columnobj;
    this.service.errorTrackingColumns(this.columnJson).subscribe(data => {
      this.message = data
      this.errorTracking = this.message.parent
      this.columnDefs = [
        {
          headerName: 'Error Tracking',
          children: [
            {
              headerName: this.errorTracking[0],
              field: this.errorTracking[0],
              minWidth: 180,
              headerCheckboxSelection: true,
              headerCheckboxSelectionFilteredOnly: true,
              checkboxSelection: true,
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[1],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[2],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[3],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[4],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[5],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[6],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              headerName: 'Actions',
              field: 'action',
              cellRendererFramework: CellCustomMilestoneComponent,
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            }
          ]
        }
      ];
    })
    this.whichdashboard = undefined;
  }


  updateRows() {
    console.log("update row clicked")
    this.requestBuilder1()
    this.service.errorTracking(this.jsonRequest).subscribe(data => {
      this.gridApi.setRowData([])
      this.loading = false;
      console.log("updated data")
      this.message = data
      console.log(data[0])
      var newData = data;
      if (newData[0] !== undefined) {
        this.gridApi.updateRowData({ add: newData });
      }
      //this.clearVar();
    })
  }
  clearVar() {

    this.businteraction = undefined;
    this.whichdashboard = undefined;

    console.log("cleared variables")
  }

  testme() {
    console.log(this.dateRanage)
  }

  onSelectionChanged(){
    this.obj1 = {}
    this.jsonRepushRequest = <JSON>this.obj1;
    this.selectedObj = []
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map(node => node.data);
    console.log("all data")
    console.log(selectedData)
    for (let i = 0; i < selectedData.length; i++) {
      var timepass = {
        "referenceno": selectedData[i].referenceno,
        "interfaceid": selectedData[i].activityname,
        "transrefno": selectedData[i].transrefno,
        "processtimestamp": selectedData[i].processtimestamp,
        "processtype": selectedData[i].processtype
      }
      this.selectedObj.push(timepass)
      console.log(this.selectedObj)
    }
    console.log("filter data")
    console.log(this.selectedObj)
    this.finalObj = {
      "dashboard": logdates.logdashboardname,
      "username": this.username
    }
    this.finalObj["requests"] = this.selectedObj
    console.log(this.finalObj)
    this.service.rePush(this.finalObj).subscribe(data => {
      alert(selectedData.length + " request pushed successfully")
    }, error => {
      this.message = error
      console.error(this.message.error.error)
      alert(this.message.error.error)
    })
  }

}
