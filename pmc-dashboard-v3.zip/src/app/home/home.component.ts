import { Component, HostListener, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { RestserviceService } from '../restservice.service';
import { config, environment } from 'src/environments/environment';
import { Subject } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import { interval, Subscription } from 'rxjs';
import { NgbModal, ModalDismissReasons,NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import {NgbDate, NgbDateParserFormatter} from '@ng-bootstrap/ng-bootstrap';
import { TestComponent } from '../test/test.component';
import { takeWhile } from 'rxjs/operators';
import * as CryptoJS from 'crypto-js';

declare var $: any;
//export let browserRefresh = false;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})



export class HomeComponent implements OnInit {
  private gridApi;
  private gridColumnApi;
  public columnDefs = [];
  private columnDefs1 = [];
  private sortingOrder;
  public defaultColDef;
  public browserRefresh: boolean;
  userActivity;
  userInactive: Subject<any> = new Subject();
  jwtHelper = new JwtHelperService();
  rowData: any;
  dateRanage: any;
  dashboardname: any;
  criteriatype: any;
  billtype: any;
  dealerordertype: any;
  alert: boolean = false

  message: any;
  usercelldata: any
  userid: number;
  userMobile;
  userEmail;
  refreshedToken: any
  users: any;
  startDate: any;
  endDate: any;
  jsonRequest: JSON;
  stringJson:string;
  obj: any;
  params: any;
  loading = false;
  showFiller = false;
  dashboard: any;

  recharge: boolean = false;
  billplanchange: boolean = false;
  dealerorder: boolean = false;
  tpdigitalservice: boolean = false;
  digitalplanconfiguration: boolean = false;
  entplanconfiguration: boolean = false;

  criteriacomm:boolean = true;
  criteriabill:boolean = true;
  criteriadealer:boolean = true;

  subscription: Subscription;
  time1 = { hour: 0, minute: 0 };
  time2 = { hour: 23, minute: 59 };
  hoveredDate: NgbDate | null = null;
  filter :any;
  paginationPageSize:any;

  constructor(private http: HttpClient,
    private router: Router,
    private service: RestserviceService,
    private modalService: NgbModal,public formatter: NgbDateParserFormatter,
    private calendar: NgbCalendar,
  ) {

    this.paginationPageSize = 23;
    this.defaultColDef = {
      flex: 1,
      minWidth: 100,
      enableValue: true,
      enableRowGroup: true,
      enablePivot: true,
      sortable: true,
      filter: true,
    }

    this.service.getalldashboardsbyuser().subscribe(data=>{
      console.log("%%%%%%%%%%%%%%%%%%%%%%%")
      console.log(data)
      this.dashboard = data
      this.hideandshow2();
    })

    // this.subscription = interval(60000).subscribe(val => this.autoUpdateRows());

  }

  // datepicker configuration
  public today: Date = new Date();
  public currentYear: number = this.today.getFullYear();
  public currentMonth: number = this.today.getMonth();
  public currentDay: number = this.today.getDate();
  public presets = [
    { label: 'Today', start: new Date(), end: new Date() },
    { label: 'This Month', start: new Date(new Date().setDate(1)), end: new Date() }
  ];
  public htmlAttributes = { name: "range", placeholder: "select date" };
  public maxDate: Object = new Date(this.currentYear, this.currentMonth, this.currentDay);
  //datepicker configuration end

  //autofit
  sizeToFit() {
    this.gridApi.sizeColumnsToFit();
  }
  autoSizeAll(skipHeader) {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds, skipHeader);
  }
  //end of autoSizeColumns

  //main mathod execution
  onGridReady(params) {
    this.loading = true;
    this.requestBuilder()
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
    let dataresp = this.service.dashboardSummary(this.jsonRequest);
    dataresp.subscribe(data => {
      this.loading = false;
      console.log("data received");
      this.message = data
      console.log(data);
      //this.rowData = data;
      var abc = data[0];
      console.log("abc is");
      console.log(abc)
      if (abc === undefined) {
        let abc = { criteria: "UNKNOWN", inprogress: 0, cancelled: 0, received: 3, failed: 1, completed: 2 }
        for (var key in abc) {
          this.columnDefs.push({
            headerName: key, field: key
          })
          params.api.setColumnDefs(this.columnDefs);
        }
        //this.users = data
        //console.log(this.users)
        //this.users = this.message.resultStatus
        //console.log(this.users)
        //const usersJson: any[] = Array.of(this.users);
        //console.log(usersJson)
        params.api.setRowData(this.users = []);
      } else {
        for (var key in abc) {
          this.columnDefs.push({
            headerName: key, field: key, filter: true,
            sortable: true, sortingOrder: ["asc", "desc"], suppressSizeToFit: true, resizable: true
          })
          params.api.setColumnDefs(this.columnDefs);

        }
        params.api.setRowData(this.users = data);
        console.log(this.users)
      }

    })

  }
  //end of main method

  //create request obj
  // rangeDate() {
  //   let currentDate = new Date();
  //   let earlierDate = new Date();
  //   earlierDate.setDate(currentDate.getDate() - 7);
  //   //this.defaultDateRange = earlierDate +"-"+ currentDate;
  //   if (this.dateRanage !== undefined) {
  //     let date: Date = new Date(this.dateRanage[0]);
  //     var month = date.getMonth() + 1
  //     this.startDate = date.getFullYear() + '-' + month + '-' + date.getDate() + " 00:00:00.000"
  //     let dateStart = date.getFullYear() + '-' + month + '-' + date.getDate()

  //     let date1: Date = new Date(this.dateRanage[1]);
  //     var month = date1.getMonth() + 1
  //     this.endDate = date1.getFullYear() + '-' + month + '-' + date1.getDate() + " 23:59:59.999"
  //     let dateEnd = date1.getFullYear() + '-' + month + '-' + date1.getDate()

  //     //for date placeholder
  //     this.dateRanage = dateStart + " to " + dateEnd
  //   } else {
  //     var month = currentDate.getMonth() + 1
  //     var earliermonth = earlierDate.getMonth() + 1
  //     this.startDate = earlierDate.getFullYear() + '-' + earliermonth + '-' + earlierDate.getDate() + " 00:00:00.000"
  //     this.endDate = currentDate.getFullYear() + '-' + month + '-' + currentDate.getDate() + " 23:59:59.999"
  //     //this.startDate = "2021-07-26 00:00:00.000"
  //     //this.endDate = "2021-08-01 23:59:59.999"

  //     //for date placeholder
  //     let dateStart = earlierDate.getFullYear() + '-' + earliermonth + '-' + earlierDate.getDate()
  //     let dateEnd = currentDate.getFullYear() + '-' + month + '-' + currentDate.getDate()
  //     this.dateRanage = dateStart + " to " + dateEnd
  //     //this.endDate = earlierDate.getFullYear() + '-' + earliermonth + '-' + earlierDate.getDate() + " 00:00:00.000"
  //   }

  //   if (this.criteriatype === undefined) {
  //     this.criteriatype = "channel"
  //   }
  //   if (this.dashboardname == undefined) {
  //     if (localStorage.getItem("role") === "admin") {
  //       let roles = config.admin
  //       this.dashboardname = roles[0]
  //     } else if (localStorage.getItem("role") === "user") {
  //       let roles = config.user
  //       this.dashboardname = roles[0]
  //     } else {
  //       console.log("undefined role")
  //     }
  //   }
  //   this.obj = {
  //     "criteria": this.criteriatype, "dashboard": this.dashboardname,
  //     "fromtimestamp": this.startDate, "totimestamp": this.endDate
  //   }
  //   this.jsonRequest = <JSON>this.obj;
  //   if (this.billtype !== undefined && this.billtype !== null && this.dashboardname === "billplanchange") {
  //     this.jsonRequest["type"] = this.billtype;
  //   }

  //   if (this.dealerordertype !== undefined && this.dealerordertype !== null && this.dashboardname === "dealerorder") {
  //     this.jsonRequest["criteria"] = this.dealerordertype;
  //   }
  //   console.log("json obj created")
  //   console.log(this.jsonRequest)
  // }
  //end of request obj

  role:any;
  requestBuilder() {
    this.filter = ""
    let currentDate = new Date();
    let earlierDate = new Date();
    earlierDate.setDate(currentDate.getDate() - 7);
    if(this.dateRanage !== undefined) {
      // this.startDate = this.startDate+ " "+ this.time1.hour+":"+this.time1.minute+":"+"00.000"
      // this.endDate = this.endDate+ " "+ this.time2.hour+":"+this.time2.minute+":"+"00.000"
      let date: Date = new Date(this.dateRanage[0]);
      var month = date.getMonth() + 1
      this.startDate = date.getFullYear() + '-' + ("0" + month).slice(-2) + '-' + ("0" + date.getDate()).slice(-2)+ " "+ this.time1.hour+":"+this.time1.minute+":"+"00.000"
      let dateStart = date.getFullYear() + '-' + month + '-' + date.getDate()

      let date1: Date = new Date(this.dateRanage[1]);
      var month = date1.getMonth() + 1
      this.endDate = date1.getFullYear() + '-' + ("0" + month).slice(-2) + '-' + ("0" + date1.getDate()).slice(-2)+ " "+ this.time2.hour+":"+this.time2.minute+":"+"00.000"
      let dateEnd = date1.getFullYear() + '-' + month + '-' + date1.getDate()

      //for date placeholder
      //this.dateRanage = dateStart + " to " + dateEnd
    }else{
      var month = currentDate.getMonth() + 1
      var earliermonth = earlierDate.getMonth() + 1
      this.startDate = earlierDate.getFullYear() + '-' + ("0" + earliermonth).slice(-2) + '-' + ("0" + earlierDate.getDate()).slice(-2) + " 00:00:00.000"
      this.endDate = currentDate.getFullYear() + '-' + ("0" + month).slice(-2) + '-' + ("0" + currentDate.getDate()).slice(-2) + " 23:59:59.999"
      //this.startDate = "2021-07-26 00:00:00.000"
      //this.endDate = "2021-08-01 23:59:59.999"

    }



    if (this.criteriatype === undefined) {
      this.criteriatype = "channel"
    }

    if (this.dashboardname === undefined) {

      try {
        const bytes = CryptoJS.AES.decrypt(localStorage.getItem("rolep"), environment.encryptSecretKey);
        if (bytes.toString()) {
          this.role = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        }        
      } catch (e) {
        console.log(e);
      }

      if (this.role === "admin") {
        let roles = config.admin
        this.dashboardname = roles[0]
      } else if (this.role === "user") {
        let roles = config.user
        this.dashboardname = roles[0]
      } else {
        console.log("undefined role")
      }
    }

    this.obj = {
      "criteria": this.criteriatype, "dashboard": this.dashboardname,
      "fromtimestamp": this.startDate,
       "totimestamp": this.endDate
    }
    this.jsonRequest = <JSON>this.obj;

    if (this.billtype !== undefined && this.billtype !== null && this.dashboardname === "billplanchange") {
      this.jsonRequest["type"] = this.billtype;
    }

    if (this.dealerordertype !== undefined && this.dealerordertype !== null && this.dashboardname === "dealerorder") {
      this.jsonRequest["criteria"] = this.dealerordertype;
    }

    console.log("json obj created")
    console.log(this.jsonRequest)

    for (var key in this.jsonRequest) {
      if (this.jsonRequest.hasOwnProperty(key)) {
          this.filter =  this.filter + (key + " = " + this.jsonRequest[key]+ ", ");
      }
  }

  this.startDate = undefined;
  this.endDate = undefined;

  }




  updateRows() {
    console.log("update row clicked")
    this.loading = true;
    this.requestBuilder()
    this.service.dashboardSummary(this.jsonRequest).subscribe(data => {
      this.loading = false;
      console.log("updated data")
      this.message = data
      console.log(data[0])
      this.gridApi.setRowData([])
      var newData = data;
      this.gridApi.updateRowData({ add: newData });
    })
  }

  autoUpdateRows() {
    console.log("auto update start")
    //this.rangeDate()
    this.service.dashboardSummary(this.jsonRequest).subscribe(data => {
      console.log("auto update successfull")
      this.message = data
      this.gridApi.setRowData([])
      var newData = data;
      this.gridApi.updateRowData({ add: newData });
    })
  }

  ngOnInit(): void {
    $("#trackdash").css("background-color", "#9ee6f7");
    //this.hideanShowGame()
    //this.hideandshow2()
    //this.requestBuilder()

    // this.browserRefresh = browserRefresh;
    // //    if(this.browserRefresh){
    // //    this.generateRefreshedToken();
    // // }
    // console.log('refreshed?:', browserRefresh);
    // this.setTimeout();
    // this.userInactive.subscribe(data => {
    //   console.log("Session Expired admin")
    //   this.logout();
    // }
    //);
  }

  logout() {
    // Remove the token from the localStorage.
    localStorage.removeItem("token")
    localStorage.removeItem("role")
    localStorage.removeItem("username")
    this.router.navigate(['']);
  }

  //jquery to hide dropdown childrens
  // hideanShowGame() {
  //   $("#dashboard").children('option').hide();
    
  //   let storedRole = localStorage.getItem("role")
  //   if (storedRole === "admin") {
  //     this.dashboard = config.admin;
  //   } else if (storedRole === "user") {
  //     this.dashboard = config.user;
  //   }

  //   for (let i = 0; i < this.dashboard.length; i++) {
  //     let showitem = this.dashboard[i]
  //     $("#dashboard option[value=" + showitem + "]").show();
  //   }
  // }
  //end of hide option

  //export to csv
  exporttocsv() {
    var params = {
    };
    this.gridApi.exportDataAsCsv(params);
  }
  //end

  //idle timeouts
  setTimeout() {
    this.userActivity = setTimeout(() => this.userInactive.next(undefined), environment.idleSessionExpired);
  }
  ngOnDestroy() {
    clearInterval(this.userActivity);
    //this.subscription.unsubscribe();
  }

  @HostListener('window:mousemove') refreshUserState() {
    clearTimeout(this.userActivity);
    this.setTimeout();
  }
  @HostListener('window:scroll') refreshUserStatescroll() {
    clearTimeout(this.userActivity);
    this.setTimeout();
  }
  @HostListener('document:keypress') refreshUserStatekeypress() {
    clearTimeout(this.userActivity);
    this.setTimeout();
  }
  //end class

  errorDashboard() {
    this.router.navigate(["/error"])
    .then(() => {
      window.location.reload();
    });
  }

  homeDashboard() {
    this.router.navigate(["/home"])
    .then(() => {
      window.location.reload();
    });
  }

  trackingDashboard() {
    this.router.navigate(["/tracking"])
    .then(() => {
      window.location.reload();
    });
  }

  nameChanged(arg) {
    // $(".type").hide();
    // $("." + arg).show();
    // if (arg == "dealerorder") {
    //   $("." + "dealerorderhide").hide();
    // } else {
    //   $("." + "dealerorderhide").show();
    // }

    $("." + "recharge").hide();
    $("." + "billplanchange").hide();
    $("." + "dealerorder").hide();
    $("." + "tpdigitalservice").hide();
    $("." + "digitalplanconfiguration").hide();
    $("." + "entplanconfiguration").hide();
    console.log(arg)
    $(".type").hide();
    $("." + arg).show();

    if(arg === "recharge" || arg === "tpdigitalservice" || arg === "digitalplanconfiguration" || arg === "entplanconfiguration"){
      this.criteriacomm = true;
    }
    if(arg === "billplanchange"){
      this.criteriabill = true;
    }
    if(arg === "dealerorder"){
      this.criteriadealer = true;
    }

  }

  openVerticallyCentered(content) {
    this.dashboardname = undefined;
    this.criteriacomm = false;
    this.criteriabill = false;
    this.criteriadealer = false;
    this.modalService.open(content, { centered: true });
  }

  storedRole:any
  hideandshow2() {
    console.log("hide and show")
    try {
      const bytes = CryptoJS.AES.decrypt(localStorage.getItem("rolep"), environment.encryptSecretKey);
      if (bytes.toString()) {
        console.log("role p is ")
        console.log(JSON.parse(bytes.toString(CryptoJS.enc.Utf8)))
        this.storedRole = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
      }
      
    } catch (e) {
      console.log(e);
    }

    //this.storedRole = localStorage.getItem("role")
    
    //this.dashboard = config.dashboards
    // if (this.storedRole === "admin") {
    //   this.dashboard = config.admin;
    // } else if (this.storedRole === "user") {
    //   this.dashboard = config.user;
    // }

    if (this.dashboard.includes("recharge")) {
      this.recharge = true;
    }
    if (this.dashboard.includes("billplanchange")) {
      this.billplanchange = true
    }
    if (this.dashboard.includes("dealerorder")) {
      this.dealerorder = true;
    }
    if (this.dashboard.includes("tpdigitalservice")) {
      this.tpdigitalservice = true
    }
    if (this.dashboard.includes("digitalplanconfiguration")) {
      this.digitalplanconfiguration = true;
    }
    if (this.dashboard.includes("entplanconfiguration")) {
      this.entplanconfiguration = true
    }

  }

  valueEmittedFromChildComponent: any;
  parrentEventHandlerFunction(valueEmitted){
    this.valueEmittedFromChildComponent = valueEmitted;
}
valueEmittedFromChildComponentMilestone: any;
  parrentEventHandlerFunctionMilestone(valueEmitted){
    this.valueEmittedFromChildComponentMilestone = valueEmitted;
}

}
