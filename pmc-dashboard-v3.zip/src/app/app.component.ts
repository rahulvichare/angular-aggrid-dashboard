import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  })
export class AppComponent implements OnInit {

 
  constructor() {
    
   }

  ngOnInit(): void {
    
  }

valueEmittedFromChildComponent: any;
  parrentEventHandlerFunction(valueEmitted){
    this.valueEmittedFromChildComponent = valueEmitted;
}
valueEmittedFromChildComponentMilestone: any;
  parrentEventHandlerFunctionMilestone(valueEmitted){
    this.valueEmittedFromChildComponentMilestone = valueEmitted;
}
}