import { Component, HostListener, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { RestserviceService } from '../restservice.service';
import { config, environment } from 'src/environments/environment';
import { Subject } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-homedashboard',
  templateUrl: './homedashboard.component.html',
  styleUrls: ['./homedashboard.component.css']
})
export class HomedashboardComponent implements OnInit {
  message: any;
  usercelldata: any
  userid: number;
  userMobile;
  userEmail;
  refreshedToken: any
  users: any;
  startDate: any;
  endDate: any;
  jsonRequest: JSON;
  obj: any;
  params: any;
  loading = false;
  showFiller = false;
  dashboard: any;

  public browserRefresh: boolean;
  userActivity;
  userInactive: Subject<any> = new Subject();
  jwtHelper = new JwtHelperService();
  rowData: any;
  dateRanage: any;
  dashboardname: any;
  criteriatype: any;
  billtype: any;
  dealerordertype: any;
  alert: boolean = false

  //datepicker configuration
  public today: Date = new Date();
  public currentYear: number = this.today.getFullYear();
  public currentMonth: number = this.today.getMonth();
  public currentDay: number = this.today.getDate();
  public presets = [
    { label: 'Today', start: new Date(), end: new Date() },
    { label: 'This Month', start: new Date(new Date().setDate(1)), end: new Date() }
  ];
  public htmlAttributes = { name: "range", placeholder: "select date" };
  public maxDate: Object = new Date(this.currentYear, this.currentMonth, this.currentDay);
  //datepicker configuration end
  data:any;

  constructor(private http: HttpClient,
    private router: Router,
    private service: RestserviceService) { }

  ngOnInit(): void {
    this.callHomeDashboard()
    this.data = []
  }

  role:any;
  rangeDate() {
    let currentDate = new Date();
    let earlierDate = new Date();
    earlierDate.setDate(currentDate.getDate() - 7);
    //this.defaultDateRange = earlierDate +"-"+ currentDate;
    if (this.dateRanage !== undefined) {
      let date: Date = new Date(this.dateRanage[0]);
      var month = date.getMonth() + 1
      this.startDate = date.getFullYear() + '-' + month + '-' + date.getDate() + " 00:00:00.000"
      let dateStart = date.getFullYear() + '-' + month + '-' + date.getDate()

      let date1: Date = new Date(this.dateRanage[1]);
      var month = date1.getMonth() + 1
      this.endDate = date1.getFullYear() + '-' + month + '-' + date1.getDate() + " 23:59:59.999"
      let dateEnd = date1.getFullYear() + '-' + month + '-' + date1.getDate()
      
      //for date placeholder      
      this.dateRanage = dateStart + " to " + dateEnd
    } else {
      var month = currentDate.getMonth() + 1
      var earliermonth = earlierDate.getMonth() + 1
      this.startDate = earlierDate.getFullYear() + '-' + earliermonth + '-' + earlierDate.getDate() + " 00:00:00.000"
      this.endDate = currentDate.getFullYear() + '-' + month + '-' + currentDate.getDate() + " 23:59:59.999"
      
      //for date placeholder
      let dateStart = earlierDate.getFullYear() + '-' + earliermonth + '-' + earlierDate.getDate()
      let dateEnd = currentDate.getFullYear() + '-' + month + '-' + currentDate.getDate()
      this.dateRanage = dateStart + " to " + dateEnd
      //this.endDate = earlierDate.getFullYear() + '-' + earliermonth + '-' + earlierDate.getDate() + " 00:00:00.000"
    }

    if (this.criteriatype === undefined) {
      this.criteriatype = "channel"
    }
    if (this.dashboardname == undefined) {

      try {
        const bytes = CryptoJS.AES.decrypt(localStorage.getItem("rolep"), environment.encryptSecretKey);
        if (bytes.toString()) {
          this.role = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        }        
      } catch (e) {
        console.log(e);
      }

      if (this.role === "admin") {
        let roles = config.admin
        this.dashboardname = roles[0]
      } else if (this.role === "user") {
        let roles = config.user
        this.dashboardname = roles[0]
      } else {
        console.log("undefined role")
      }
    }
    this.obj = {
      "criteria": this.criteriatype, "dashboard": this.dashboardname,
      "fromtimestamp": this.startDate, "totimestamp": this.endDate
    }
    this.jsonRequest = <JSON>this.obj;
    if (this.billtype !== undefined && this.billtype !== null && this.dashboardname === "billplanchange") {
      this.jsonRequest["type"] = this.billtype;
    }

    if (this.dealerordertype !== undefined && this.dealerordertype !== null && this.dashboardname === "dealerorder") {
      this.jsonRequest["criteria"] = this.dealerordertype;
    }
    console.log("json obj created")
    console.log(this.jsonRequest)
  }
  //end of request obj


  callHomeDashboard(){
    this.rangeDate()
    this.service.dashboardSummary(this.jsonRequest).subscribe(data => {
      this.message = data
       let abc = data[0]
       if(abc !== undefined) {
         this.data = data
       }else{
         this.data = [this.message.resultStatus]
       }
    })
  }
}
