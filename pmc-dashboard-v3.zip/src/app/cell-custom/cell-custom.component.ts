import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { RestserviceService } from '../restservice.service';
import { logdates } from '../failure-stats/failure-stats.component';
import { CellCustomMilestoneComponent } from '../cell-custom-milestone/cell-custom-milestone.component';

import { config, environment } from 'src/environments/environment';
import { Subject } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import { interval, Subscription } from 'rxjs';

declare var $: any;
export var cellCustomComponent = {
  transrefno: "",
  referenceno: "",
  transDate: ""
};

@Component({
  selector: 'app-cell-custom',
  templateUrl: './cell-custom.component.html',
  styleUrls: ['./cell-custom.component.css']
})
export class CellCustomComponent implements OnInit {
  data: any;
  params: any;
  closeResult = '';
  activityName: any;
  error: any;
  activityCount: any;
  public defaultColDef;
  private gridApi;
  columnDefs = [];
  users: any;
  jsonRequest: JSON;
  columnJson: JSON;
  jsonRepushRequest: any;
  obj: any;
  obj1: any;
  columnobj: any;
  message: any;
  errorTracking = [];
  selectobj: any;
  selectJson: JSON;
  selectedObj = [];
  finalObj: any;
  private gridColumnApi;
  username: string = localStorage.getItem('username');
  paginationPageSize:any;


  constructor(
    private modalService: NgbModal,
    private http: HttpClient,
    private router: Router,
    private service: RestserviceService
  ) {

    this.paginationPageSize = 17;
    this.defaultColDef = {
      flex: 1,
      minWidth: 100,
      enableValue: true,
      enableRowGroup: true,
      enablePivot: true,
      sortable: true,
      filter: true,
    }
  }

  onGridReady(params) {
    this.errorTrackingColumns();
    this.requestBuilder()
    this.gridApi = params.api;
    //this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
    let dataresp = this.service.errorTracking(this.jsonRequest);
    dataresp.subscribe(data => {
      params.api.setRowData(data);
    })
    this.columnDefs = []
  }

  errorTrackingColumns() {
    this.columnobj = {
      "dashboard": logdates.logdashboardname,
      "parent": "errorTrackingResponse"
    }
    this.columnJson = <JSON>this.columnobj;
    this.service.errorTrackingColumns(this.columnJson).subscribe(data => {
      this.message = data
      this.errorTracking = this.message.parent
      this.columnDefs = [
        {

          headerName: 'Error Tracking',
          children: [
            {
              headerName: this.errorTracking[0],
              field: this.errorTracking[0],
              minWidth: 180,
              headerCheckboxSelection: true,
              headerCheckboxSelectionFilteredOnly: true,
              checkboxSelection: true,
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[1],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[2],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[3],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[4],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[5],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              field: this.errorTracking[6],
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            },
            {
              headerName: 'Actions',
              field: 'action',
              cellRendererFramework: CellCustomMilestoneComponent,
              filter: true,
              sortable: true,
              sortingOrder: ["asc", "desc"],
              suppressSizeToFit: true,
              resizable: true
            }
          ]
        }
      ];
      console.log(this.errorTracking[0])
    })
  }
  // onGridReady(params) {
  //   this.requestBuilder()
  //   this.gridApi = params.api;
  //   //this.gridColumnApi = params.columnApi;
  //   //params.api.sizeColumnsToFit();
  //   let dataresp = this.service.tracking(this.jsonRequest);
  //   dataresp.subscribe(data => {
  //     console.log("data received");
  //     this.message = data
  //     console.log(data);
  //     var abc = data[0];
  //     console.log("abc is");
  //     console.log(abc)
  //     if (abc === undefined) {
  //       for (var key in this.message.resultStatus) {
  //         this.columnDefs.push({
  //           headerName: key, field: key
  //         })
  //         params.api.setColumnDefs(this.columnDefs);
  //       }
  //       this.users = data
  //       //console.log(this.users)
  //       this.users = this.message.resultStatus
  //       //console.log(this.users) 
  //       const usersJson: any[] = Array.of(this.users);
  //       //console.log(usersJson)
  //       params.api.setRowData(this.users = usersJson);
  //     } else {
  //       for (var key in abc) {
  //         this.columnDefs.push({
  //           headerName: key, field: key, filter: true,
  //           sortable: true, sortingOrder: ["asc", "desc"], suppressSizeToFit: true, resizable: true
  //         })
  //         params.api.setColumnDefs(this.columnDefs);
  //       }
  //       params.api.setRowData(this.users = data);
  //       console.log(this.users)
  //     }
  //   })
  // }

  agInit(params) {
    this.params = params;
    this.data = params.value;
  }

  editRow() {
    let rowData = this.params;
    let i = rowData.data;
    console.log(i);
  }

  refresh(params?: any): boolean {
    return true;
  }
  onClick($event) {
    if (this.params.onClick instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.onClick(params);

    }
  }

  onRowClicked(args) {
    cellCustomComponent.transrefno = args.data.transrefno
    console.log(cellCustomComponent.transrefno)
    cellCustomComponent.referenceno = args.data.referenceno
    console.log(cellCustomComponent.referenceno)
    cellCustomComponent.transDate = args.data.transactiontimestamp
    console.log(cellCustomComponent.transDate)
    console.log("on row clicked on cell custom componet set varialbles")
  }

  open(content) {
    console.log("view clicked")
    this.showData()
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  openXl(contentlogs) {
    this.modalService.open(contentlogs, { size: 'xl', scrollable: true });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  showData() {
    let rowData = this.params;
    let i = rowData.data;
    this.activityName = i.activityname
    this.error = i.errorcode
    this.activityCount = i.total
    console.log(this.activityCount)
  }

  ngOnInit(): void { }

  requestBuilder() {
    let rowData = this.params;
    let i = rowData.data;
    let errorcode = i.errorcode
    var newarr = errorcode.split("-");
    var errorResult = newarr[0]
    this.obj = {
      "dashboard": logdates.logdashboardname,
      "fromtimestamp": logdates.logstartDate,
      "totimestamp": logdates.logendDate,
      "activityname": i.activityname,
    }
    this.jsonRequest = <JSON>this.obj;
    if (errorResult !== undefined && errorResult !== "") {
      this.jsonRequest["errorcode"] = errorResult;
    }
    console.log(this.jsonRequest);
  }

  onSelectionChanged() {
    this.obj1 = {}
    this.jsonRepushRequest = <JSON>this.obj1;
    this.selectedObj = []
    let selectedNodes = this.gridApi.getSelectedNodes();
    let selectedData = selectedNodes.map(node => node.data);
    console.log("all data")
    console.log(selectedData)
    for (let i = 0; i < selectedData.length; i++) {
      var timepass = {
        "referenceno": selectedData[i].referenceno,
        "interfaceid": selectedData[i].activityname,
        "transrefno": selectedData[i].transrefno,
        "processtimestamp": selectedData[i].processtimestamp,
        "processtype": selectedData[i].processtype
      }
      this.selectedObj.push(timepass)
      console.log(this.selectedObj)
    }
    console.log("filter data")
    console.log(this.selectedObj)
    this.finalObj = {
      "dashboard": logdates.logdashboardname,
      "username": this.username
    }
    this.finalObj["requests"] = this.selectedObj
    console.log(this.finalObj)
    this.service.rePush(this.finalObj).subscribe(data => {
      alert(selectedData.length + " request pushed successfully")
    }, error => {
      this.message = error
      console.error(this.message.error.error)
      alert(this.message.error.error)
    })
    this.gridApi.deselectAll();
  }

  repushhideandshow(){
    this.service.getpmcdashboard().subscribe(data=>{
      let dashboards:any = data;
      const entries = Object.entries(data);
      console.log(typeof entries)         
    })
  }

}
