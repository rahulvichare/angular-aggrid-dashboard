// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //apiBaseUrl: 'http://localhost:8891/processmonitoring',
  apiBaseUrl: 'http://10.144.114.114:32009/processmonitoring',
  pmcLogin: 'http://localhost:8090/digitalapi/app',
  //ldapEndPoint: "http://10.144.114.114:32009/processmonitoring/authenticate",
  ldapEndPoint: "http://10.144.114.114:30020/ldapservice/authenticate",
  //ldapEndPoint: "http://10.144.21.40:30888/processmonitoring/authenticate",
  idleSessionExpired: 900000,
  encryptSecretKey: '75lvsfy6P7hy5:/bUiF4la@G@<?JqO'
};

export var config = {
  admin:["recharge","billplanchange","dealerorder","tpdigitalservice","digitalplanconfiguration","entplanconfiguration"],
  user:["recharge","billplanchange","tpdigitalservice"],
  dashboards: []
};